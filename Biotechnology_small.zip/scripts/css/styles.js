<script>
   $(document).ready(function() {
     $head = $('#header');
     $head.prepend('<img src=\"http://sydney.edu.au/images/content/about/logo-mono.jpg" style=\"float: right;width: 200px;\"/>')
   });
</script>

<footer>
<br>
<hr>
<p>© University of Sydney</p>
</footer>