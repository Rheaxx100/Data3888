<script>
   $(document).ready(function() {
     $head = $('#header');
     $head.prepend('<img src="figure/dataholmes.png" style="float: right;width: 60px">')
   });
</script>

<footer>
<br>
<hr>
<p>© University of Sydney 2023</p>
</footer>